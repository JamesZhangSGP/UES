function d=af2(x)
d=x.^(1/2);
end