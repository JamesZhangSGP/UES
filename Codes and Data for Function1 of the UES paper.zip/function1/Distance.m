function D=Distance(ST,x)
[row,line]=size(ST);
D=zeros(line,1);
for i=1:line
    t=0;
    for j=1:row
        t=t+(ST(j,i)-x(j)).^2;
    end
    D(i)=sqrt(t);
end
end