function d=af4(x)
d=x.^(4);
end