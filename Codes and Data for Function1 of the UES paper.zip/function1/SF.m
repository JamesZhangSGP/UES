function f=SF(S)
[~,line]=size(S);
f=ones(line,1);
for i=1:line
   f(i)=F(S(:,i));
end


