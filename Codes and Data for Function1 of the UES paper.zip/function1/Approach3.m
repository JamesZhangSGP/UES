function W=Approach3(DW1,d)
[~,lc]=min(d);
ZW=DW1(:,lc);
c=sum(ZW);
W=ZW./c;
end

