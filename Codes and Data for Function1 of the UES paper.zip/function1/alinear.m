function d=alinear(x)
d=x;
end