function W=Approach2(DW2,invd)
ZW=DW2*invd;
c=sum(ZW);
W=ZW./c;
end

