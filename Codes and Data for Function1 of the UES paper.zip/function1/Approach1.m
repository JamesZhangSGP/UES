function W=Approach1(DW1,invd)
ZW=DW1*invd;
c=sum(ZW);
W=ZW./c;
end

