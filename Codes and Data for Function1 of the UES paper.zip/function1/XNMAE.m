function Xmae=XNMAE(Ftrain,Ftest)
[row,line]=size(Ftrain);
Xrms=zeros(row,line);
Xrmse=zeros(1,line);
Y=mean(Ftest);
for i=1:line
    for j=1:row
        Xrms(j,i)=abs(Ftrain(j,i)-Ftest(j));
        Xrmse(i)=Xrmse(i)+(Y-Ftest(j)).^2;
    end
end
Xrmse=sqrt(Xrmse.*1/row);
[XMAE,~]=max(Xrms);
Xmae=XMAE./Xrmse;