function d=af1(x)
d=x.^(1/4);
end