function f=ENTT(F1,F2,F3,T,w)
[~,line] =size(T);
f=zeros(line,1);
for i=1:line
    f(i)=w(1).*F1(i)+w(2).*F2(i)+w(3).*F3(i);
end