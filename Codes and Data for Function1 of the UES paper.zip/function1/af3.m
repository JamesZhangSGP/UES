function d=af3(x)
d=1-exp(-log(1000).*x.^8);
end