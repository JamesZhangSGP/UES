function rk=rk(S,E)
[~,line]=size(S);
WG=WGoel(E);
WG=WG';
DW1=DatapointW1(E);
for i=1:line
    WCVEG=WG*E(:,i);
    WCVEL=DW1(:,i)'*E(:,i);
    Pk=WCVEG/WCVEL;
    D=Distance(S,S(:,i));
    [R,~]=sort(D);
    if Pk>1
       rk(i)=(R(2)/2)*(1-1/Pk);
    else
       rk(i)=0;
    end
end