function W=Approach4(DW2,d)
[~,lc]=min(d);
ZW=DW2(:,lc);
c=sum(ZW);
W=ZW./c;
end

