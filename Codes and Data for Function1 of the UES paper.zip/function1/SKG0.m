function F=SKG0(f,x,T)
[row,~]=size(x);
n=ones(row,1);
theta=10.*n;
lob=1e-2.*n;
upb=20.*n;
[dmodel,~]=dacefit(x',f,@regpoly0,@corrgauss, theta, lob, upb);
F=predictor(T',dmodel);
end