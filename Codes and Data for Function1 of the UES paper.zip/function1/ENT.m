function f=ENT(FRBF,FKRG0,FPRS,w)
f=w(1).*FRBF+w(2).*FKRG0+w(3).*FPRS;
end