function d=aesine(x)
d=sin(pi/2.*x);
end