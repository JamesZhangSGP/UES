tic
clear;clc;
M=1000;
Grop=1000;
N=2;
Y=zeros(Grop*N,M);
for n=0:(Grop-1);
    X=lhsdesign(M,N);
    [row,line]=size(X);
    for i=1:row
        Y(2*n+1,i)=-5+15*X(i,1);
        Y(2*n+2,i)=0+15*X(i,2);
    end
end
xlswrite('test.xlsx',Y);
toc
