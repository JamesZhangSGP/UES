function datapointW2=DatapointW2(E)
EW=1./(E.^2);
datapointW2=EW;