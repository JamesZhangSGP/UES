function XRR=XR(Ftrain,Ftest)
[row,line]=size(Ftrain);
Xrms=zeros(1,line);
Y=mean(Ftest);
Yrms=zeros(1,line);
for i=1:line
    for j=1:row
        Xrms(i)=Xrms(i)+(Ftrain(j,i)-Ftest(j)).^2;
        Yrms(i)=Yrms(i)+(Ftest(j)-Y).^2;
    end
end
XRR=1-Xrms./Yrms;