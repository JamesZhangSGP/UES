function d=a4rd(x)
d=5.*(x).^4-4.*(x).^5;
end