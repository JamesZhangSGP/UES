tic
clear;clc;
M=30;
Grop=1000;
N=2;
Y=zeros(Grop*N,M);
for n=0:(Grop-1);
    X=lhsdesign(M,N,'criterion','maximin','iterations',100);
    [row,line]=size(X);
    for i=1:row
        Y(2*n+1,i)=-5+15*X(i,1);
        Y(2*n+2,i)=0+15*X(i,2);
    end
end
xlswrite('train30.xlsx',Y);
toc
