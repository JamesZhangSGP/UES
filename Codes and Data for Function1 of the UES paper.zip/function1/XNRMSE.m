function Xrmse=XNRMSE(Ftrain,Ftest)
[row,line]=size(Ftrain);
Xrmse=zeros(1,line);
for i=1:line
    for j=1:row
        Xrmse(i)=Xrmse(i)+(Ftrain(j,i)-Ftest(j)).^2;
    end
end
M=sum(Ftest.^2);
Xrmse=sqrt(Xrmse.*1/M);
