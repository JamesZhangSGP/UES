function f=aLx(x,B)
a=1-x;
if a==0
   f=1;
else
   f=(1-x).^(-B)/(x.^(-B)+(1-x).^(-B));
end