function ae=e(Y,ST)
[~,STline]=size(ST);
a=1:STline;
indices=repmat(a,1,1)';
eRBF=zeros(1,STline);
eKRG0=zeros(1,STline);
ePRS=zeros(1,STline);
for j=1:STline
    test=(indices==j);
    train=~test;
    trainData=ST(:,train);
    FtrainData=Y(train,:);
    testData=ST(:,test);
    FtestData=Y(test,:);
    eRBF(j)=FtestData-SRBFMQ(FtrainData,trainData,testData);
    eKRG0(j)=FtestData-SKG0(FtrainData,trainData,testData);
    ePRS(j)=FtestData-SPRS(FtrainData,trainData,testData);
end
ae=[eRBF;eKRG0;ePRS];