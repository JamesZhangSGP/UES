function datapointW1=DatapointW1(E)
[row,STline]=size(E);
EW=zeros(row,STline);
[~,cLOC]=min(E);
for j=1:STline
    EW(cLOC(j),j)=1;
end
datapointW1=EW;