function d=a3rd(x)
d=3.*(x).^2-2.*(x).^3;
end