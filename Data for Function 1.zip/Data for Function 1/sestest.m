function [F6,F7,F8,F9]=sestest(test,ST,DW1,WG,WA,dimen,RK,F1,F2,F3)
[~,tline]=size(test);
F6=zeros(tline,1);
F7=zeros(tline,1);
F8=zeros(tline,1);
F9=zeros(tline,1);
for j=1:tline
        invd=InvDistance(ST,test(:,j));
        distance=Distance(ST,test(:,j));
        [d,c]=sort(distance);
        dp=d(1)/d(2);
        dc=aesine(dp);
        W1=Approach1(DW1,invd);
        Wtry1=Atry(W1,WG,dc);
        Wtry1A=Atry(W1,WA,dc);
        WES=Wes(WG,W1,d(1),c(1),RK,dimen);
        F6(j)=ENT(F1(j),F2(j),F3(j),Wtry1);
        F7(j)=ENT(F1(j),F2(j),F3(j),WES);
        F8(j)=ENT(F1(j),F2(j),F3(j),W1);
        F9(j)=ENT(F1(j),F2(j),F3(j),Wtry1A);
end
end  