tic
clear;clc;
pool=startmatlabpool(8);
S=xlsread('train36.xlsx');
[row,line]=size(S);
T=xlsread('test.xlsx');
dimen=2;
Trainingsets=1/dimen*row-1;
parfor i=0:Trainingsets
    [ST,test]=stt(i,dimen,S,T);
    Y=SF(ST);
    Ftest=SF(test);
    ae=e(Y,ST);
    WA=WAcar(ae,3);
    F1=SRBFMQ(Y,ST,test);
    F2=SKG0(Y,ST,test);
    F3=SPRS(Y,ST,test);
    FAcar=ENTT(F1,F2,F3,test,WA);
    E=abs(ae);
    WG=WGoel(E);
    FGoel=ENTT(F1,F2,F3,test,WG);
    [trow,tline]=size(test);
    DW1=DatapointW1(E);
    RK=rk(ST,E);
    WA=WA';
    [F6,F7,F8,F9]=sestest(test,ST,DW1,WG,WA,dimen,RK,F1,F2,F3);
    FS=[F1 F2 F3 FAcar FGoel F8 F7 F6 F9];
    Xrmse(i+1,:)=XNRMSE(FS,Ftest);
    XRR(i+1,:)=XR(FS,Ftest);
    Xmae(i+1,:)=XNMAE(FS,Ftest);
end
[Xrow,Xline]=size(Xrmse);
EVA=zeros(6,Xline);
stdr=std(Xrmse);
stda=std(XRR);
stdm=std(Xmae);
for i=1:Xline
    EVA(1,i)=mean(Xrmse(:,i));
    EVA(2,i)=stdr(i)/mean(Xrmse(:,i));
    EVA(3,i)=mean(XRR(:,i));
    EVA(4,i)=stda(i)/mean(XRR(:,i));  
    EVA(5,i)=mean(Xmae(:,i));
    EVA(6,i)=stdm(i)/mean(Xmae(:,i));
end
ht={'RBF','KRG','PRS','Acar','Goel','SP','ESHGL','UES1','UES2'};
Aconclusions=[ht;num2cell(EVA)];
toc
Time=toc;
save 36
closematlabpool;
    