function d=aexp1(x)
d=exp(log(2).*x.^2)-1;
end