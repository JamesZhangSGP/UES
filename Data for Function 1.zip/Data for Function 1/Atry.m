function W=Atry(WL,WG,dc)
ZW=WL.*(1-dc)+WG.*dc;
c=sum(ZW);
W=ZW./c;
end