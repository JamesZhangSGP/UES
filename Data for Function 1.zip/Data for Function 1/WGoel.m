function W=WGoel(e)
[~,line]=size(e);
G=e.^2;
GMSE=sum(G,2)/line;
Eavg=mean(GMSE);
[Grow,~]=size(GMSE);
w=zeros(Grow,1);
for i=1:Grow
    w(i)=(GMSE(i)+0.05.*Eavg).^(-1);
end
sw=sum(w);
W=w/sw;
end