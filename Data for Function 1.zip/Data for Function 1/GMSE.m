function G=GMSE(ae,x)
[~,n] =size(ae);
D=[x(1);x(2);x(3)];
t=0;
for i=1:n 
    t=t+sum(ae(:,i).*D).^2;
end
    G=t/n;
end