function [ST,test]=stt(i,dimen,S,T)
for j=1:dimen
    ST(j,:)=S(dimen*i+j,:);
    test(j,:)=T(dimen*i+j,:);
end
end