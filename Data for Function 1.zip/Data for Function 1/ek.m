function e=ek(Y,ST)
[~,STline]=size(ST);
a=1:STline;
indices=repmat(a,1,1)';
eRBF=zeros(1,STline);
eKRG0=zeros(1,STline);
ePRS=zeros(1,STline);
for j=1:STline
    test=(indices==j);
    train=~test;
    trainData=ST(:,train);
    FtrainData=Y(train,:);
    testData=ST(:,test);
    FtestData=Y(test,:);
    eRBF(j)=abs(FtestData-SRBFMQ(FtrainData,trainData,testData));
    eKRG0(j)=abs(FtestData-SKG0(FtrainData,trainData,testData));
    ePRS(j)=abs(FtestData-SPRS(FtrainData,trainData,testData));
end
e=[eRBF;eKRG0;ePRS];