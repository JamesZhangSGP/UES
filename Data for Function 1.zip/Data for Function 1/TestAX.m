tic
clear;clc;
%---�趨���к���������;8��16�߳���Ϊ8��-----------------
pool=startmatlabpool(8);
S=xlsread('train12.xlsx');
[row,line]=size(S);
T=xlsread('test.xlsx');
%---�趨ά��----------------------------------------
dimen=2;
Trainingsets=1/dimen*row-1;
parfor i=0:Trainingsets
    [ST,test]=stt(i,dimen,S,T);
    Y=SF(ST);
    Ftest=SF(test);
     %---�趨��ϴ���ģ�͸���-----------------
    ae=e(Y,ST);
    WA=WAcar(ae,3);
    FRBF=SRBFMQ(Y,ST,test);
    FKRG=SKG0(Y,ST,test);
    FPRS=SPRS(Y,ST,test);
    E=abs(ae);
    WG=WGoel(E);
    DW1=DatapointW1(E);
    WA=WA';
    [F1,F2,F3,F4,F5,F6,F7,F8,F9,F10]=sestestax(test,ST,DW1,WG,WA,FRBF,FKRG,FPRS)
    FS=[F1 F2 F3 F4 F5 F6 F7 F8 F9 F10];
    Xrmse(i+1,:)=XNRMSE(FS,Ftest);
    XRR(i+1,:)=XR(FS,Ftest);
    Xmae(i+1,:)=XNMAE(FS,Ftest);
end
[Xrow,Xline]=size(Xrmse);
EVA=zeros(3,Xline);
for i=1:Xline
    EVA(1,i)=mean(Xrmse(:,i));
    EVA(2,i)=mean(XRR(:,i));
    EVA(3,i)=mean(Xmae(:,i));
end
ht={'Wlinear','W3rd','Wexp1','Wexp2','Wsine','WlinearA','W3rdA','Wexp1A','Wexp2A','WsineA'};
Aconclusions=[ht;num2cell(EVA)];
toc
Time=toc;
save AX
xlswrite('AXshuju.xlsx',EVA);
closematlabpool;
    