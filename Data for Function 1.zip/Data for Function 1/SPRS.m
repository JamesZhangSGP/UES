function F=SPRS(Y,ST,T)
[row,line]=size(T);
A=zeros(line,(row^2+3*row)/2+1);
A(:,1)=1;
n=1;
for i=2:(row+1)
    A(:,i)=T(n,:);
    n=n+1;
end
n=1;
for i=(row+2):(2*row+1)
    A(:,i)=(T(n,:)).^2;
    n=n+1;
end
C=nchoosek(1:row,2);
n=1;
for i=(2*row+2):(row^2+3*row)/2+1
    A(:,i)=(T(C(n,1),:)).*(T(C(n,2),:));
    n=n+1;
end
coef=PRScoef(Y,ST);
F=A*coef;
end

    
    
    
