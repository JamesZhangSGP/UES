function d=InvDistance(ST,x)
[row,line]=size(ST);
D=zeros(line,1);
for i=1:line
    t=0;
    for j=1:row
        t=t+(ST(j,i)-x(j)).^2;
    end
    if t==0
       D(i)=1;
    else
       D(i)=1/t;
    end
end
d=D;
end