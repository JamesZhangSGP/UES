function WAcar=WAcar(ae,v)
%v---������ϵĴ���ģ�͵ĸ���
n1=ones(v,1);
n2=ones(1,v);
gGMSE=@(x)GMSE(ae,x);
x0=1/v.*n2;
A=[];
b=[];
Aeq=n2;
beq=1;
lb=0.*n1; 
ub=n1;
NONLCON=[];
options=optimset('Algorithm','sqp');
[WAcar,~]=fmincon(gGMSE,x0,A,b,Aeq,beq,lb,ub,NONLCON,options);
end