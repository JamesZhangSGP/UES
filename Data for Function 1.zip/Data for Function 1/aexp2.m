function d=aexp2(x)
d=1-exp(-100.*x.^3);
end